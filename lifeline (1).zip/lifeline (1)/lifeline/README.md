# Android-Sliding-Tabs-With-Material-Design

Google has been updating many of its apps with its new material design. One of the main visual changes in the updates is the newly redesigned sliding tabs. This is a sample application from this tutorial - 

http://www.exoguru.com/android/material-design/navigation/android-sliding-tabs-with-material-design.html

![Alt text](/tabpic.png?raw=true "Sample App")
