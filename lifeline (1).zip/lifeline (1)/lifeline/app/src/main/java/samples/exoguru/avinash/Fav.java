package samples.exoguru.avinash;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Fav extends ActionBarActivity implements AdapterView.OnItemClickListener{
    SqlHandler sqlHandler;
    ListView lvCustomList;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav);
        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);
        toolbar.setLogo(R.mipmap.logo2);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        lvCustomList = (ListView) findViewById(R.id.fav_listview);
        sqlHandler = new SqlHandler(this);
        lvCustomList.setOnItemClickListener(this);

        ArrayList<Blood> bloodlist = new ArrayList<Blood>();
        bloodlist.clear();
        String query = "SELECT * FROM blood where fav='true' ";
        Cursor c1 = sqlHandler.selectQuery(query);


        if (c1 != null && c1.getCount() != 0) {
            if (c1.moveToFirst()) {
                do {
                    Blood blood = new Blood();

                    blood.setBloodg(c1.getString(c1
                            .getColumnIndex("bloodg")));
                    blood.setFullname(c1.getString(c1
                            .getColumnIndex("fullname")));
                    blood.setState(c1.getString(c1
                            .getColumnIndex("state")));
                    blood.setCity(c1.getString(c1
                            .getColumnIndex("city")));
                    blood.setArea(c1.getString(c1
                            .getColumnIndex("area")));
                    blood.setContact(c1.getString(c1
                            .getColumnIndex("contact")));
                    blood.setEmail(c1.getString(c1
                            .getColumnIndex("email")));

                    bloodlist.add(blood);

                } while (c1.moveToNext());
            }
        }


        c1.close();

        BloodAdapter bloodAdapter = new BloodAdapter(
                Fav.this, bloodlist);
        lvCustomList.setAdapter(bloodAdapter);











}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_fav, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);

        }


        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        TextView c = (TextView) view.findViewById(R.id.tbdg);
        String lbloodg = c.getText().toString();

        TextView c1 = (TextView) view.findViewById(R.id.tname);
        String lname = c1.getText().toString();

        TextView c2 = (TextView) view.findViewById(R.id.tstate);
        String lstate = c2.getText().toString();

        TextView c3 = (TextView) view.findViewById(R.id.tarea);
        String larea = c3.getText().toString();

        TextView c4 = (TextView) view.findViewById(R.id.tcity);
        String lcity = c4.getText().toString();

        TextView c5 = (TextView) view.findViewById(R.id.tcontact);
        String lcontact = c5.getText().toString();

        TextView c6 = (TextView) view.findViewById(R.id.temail);
        String lemail = c6.getText().toString();

/*
        Intent call = new Intent(Intent.ACTION_DIAL);
        call.setData(Uri.parse("tel:" + lcontact));
        startActivity(call);

*/
        Intent i = new Intent(getApplicationContext(), Next.class);
        i.putExtra("bloodg", lbloodg);
        i.putExtra("name", lname);
        i.putExtra("state", lstate);
        i.putExtra("area", larea);
        i.putExtra("city", lcity);
        i.putExtra("contact", lcontact);
        i.putExtra("email", lemail);

        startActivity(i);


        Toast.makeText(Fav.this, lbloodg, Toast.LENGTH_SHORT).show();
    }
}
