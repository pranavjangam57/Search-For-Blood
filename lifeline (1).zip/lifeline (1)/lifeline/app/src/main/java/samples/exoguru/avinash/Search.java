package samples.exoguru.avinash;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Contacts;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBarActivity;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Search extends ActionBarActivity implements View.OnClickListener, AdapterView.OnItemClickListener, AdapterView.OnItemSelectedListener {
    Toolbar toolbar;
    EditText s_city;
   ImageView search;
    ListView lvCustomList;
    String s_bloodg, s_state;
    SqlHandler sqlHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setLogo(R.mipmap.logo1);


        s_city = (EditText) findViewById(R.id.s_city);
        Spinner spinner = (Spinner) findViewById(R.id.s_spinner);
        Spinner spinner2 = (Spinner) findViewById(R.id.s_spinner2);


        // Spinner click listener
        spinner.setOnItemSelectedListener(this);
        spinner2.setOnItemSelectedListener(this);

        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("A+");
        categories.add("B+");
        categories.add("AB+");
        categories.add("O+");
        categories.add("A-");
        categories.add("B-");
        categories.add("AB-");
        categories.add("O-");
// Spinner Drop down elements

        List<String> categories1 = new ArrayList<String>();
        categories1.add("ANDRA PRADESH");
        categories1.add("ARUNACHAL PRADESH");
        categories1.add("ASSAM");
        categories1.add("BIHAR");
        categories1.add("CHHATTISGARH");
        categories1.add("GOA");
        categories1.add("GUJRAT");
        categories1.add("HARYANA");
        categories1.add("HIMACHAL PRADESH");
        categories1.add("JAMMU AND KASHMIR");
        categories1.add("JHARKHAND");
        categories1.add("KARNATAKA");
        categories1.add("KERALA");
        categories1.add("MADYA PRADESH");
        categories1.add("MAHARASHTRA");
        categories1.add("MANIPUR");
        categories1.add("MEGHALAYA");
        categories1.add("MIZORAM");
        categories1.add("NAGALAND");
        categories1.add("ORISSA");
        categories1.add("PUNJAB");
        categories1.add("RAJASTHAN");
        categories1.add("SIKKIM");
        categories1.add("TAMIL NADU");
        categories1.add("TRIPURA");
        categories1.add("UTTARANCHAL");
        categories1.add("UTTAR PRADESH");
        categories1.add("WEST BENGAL");
        categories1.add("CHANDIGARH");
        categories1.add("DAMAN AND DIU");
        categories1.add("DELHI");
        categories1.add("LAKSHDEEP");
        categories1.add("KAVARATTI");
        categories1.add("PONDICHERRY");


        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories1);
//Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        spinner2.setAdapter(dataAdapter1);

       search = (ImageView) findViewById(R.id.imageView3);
        search.setOnClickListener(this);

        lvCustomList = (ListView) findViewById(R.id.listView);
        sqlHandler = new SqlHandler(this);
        lvCustomList.setOnItemClickListener(this);

    }


    @Override
    public void onClick(View view) {

        if (view == search) {

            String ss_bloodg = String.valueOf(s_bloodg);
            ss_bloodg = ss_bloodg.toUpperCase();


            String ss_state = String.valueOf(s_state);
            ss_state = ss_state.toUpperCase();

            String ss_city = String.valueOf(s_city.getText());
            ss_city = ss_city.toUpperCase();

            if (ss_bloodg.trim().length() == 0 ||
                    ss_state.trim().length() == 0 ||
                    ss_city.toString().trim().length() == 0) {
                showMessage("Error", "Please enter all values");
                return;
            }


            ArrayList<Blood> bloodlist = new ArrayList<Blood>();
            bloodlist.clear();
            String query = "SELECT bloodg,fullname,state,city,area,contact,email FROM blood  where bloodg='" + ss_bloodg + "' and  state='" + ss_state + "' and city='" + ss_city + "'";
            Cursor c1 = sqlHandler.selectQuery(query);


            if (c1 != null && c1.getCount() != 0) {
                if (c1.moveToFirst()) {
                    do {
                        Blood blood = new Blood();

                        blood.setBloodg(c1.getString(c1
                                .getColumnIndex("bloodg")));
                        blood.setFullname(c1.getString(c1
                                .getColumnIndex("fullname")));
                        blood.setState(c1.getString(c1
                                .getColumnIndex("state")));
                        blood.setCity(c1.getString(c1
                                .getColumnIndex("city")));
                        blood.setArea(c1.getString(c1
                                .getColumnIndex("area")));
                        blood.setContact(c1.getString(c1
                                .getColumnIndex("contact")));
                        blood.setEmail(c1.getString(c1
                                .getColumnIndex("email")));

                        bloodlist.add(blood);

                    } while (c1.moveToNext());
                }
            } else {
                showMessage("Error", "NO RECORD FOUND");
            }


            c1.close();

            BloodAdapter bloodAdapter = new BloodAdapter(
                    Search.this, bloodlist);
            lvCustomList.setAdapter(bloodAdapter);


        }


    }


    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {




        s_city.setText("");

        s_city.requestFocus();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_search, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);

        }
        if (id == R.id.life) {
            startActivity(new Intent(this, Utility.class));
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//data from list view
        TextView c = (TextView) view.findViewById(R.id.tbdg);
        String lbloodg = c.getText().toString();

        TextView c1 = (TextView) view.findViewById(R.id.tname);
        String lname = c1.getText().toString();

        TextView c2 = (TextView) view.findViewById(R.id.tstate);
        String lstate = c2.getText().toString();

        TextView c3 = (TextView) view.findViewById(R.id.tarea);
        String larea = c3.getText().toString();

        TextView c4 = (TextView) view.findViewById(R.id.tcity);
        String lcity = c4.getText().toString();

        TextView c5 = (TextView) view.findViewById(R.id.tcontact);
        String lcontact = c5.getText().toString();

        TextView c6 = (TextView) view.findViewById(R.id.temail);
        String lemail = c6.getText().toString();

/*
        Intent call = new Intent(Intent.ACTION_DIAL);
        call.setData(Uri.parse("tel:" + lcontact));
        startActivity(call);

*/
        Intent i = new Intent(getApplicationContext(), Next.class);
        i.putExtra("bloodg", lbloodg);
        i.putExtra("name", lname);
        i.putExtra("state", lstate);
        i.putExtra("area", larea);
        i.putExtra("city", lcity);
        i.putExtra("contact", lcontact);
        i.putExtra("email", lemail);

        startActivity(i);





    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Spinner spin = (Spinner) parent;
        Spinner spin2 = (Spinner) parent;

        if (spin.getId() == R.id.s_spinner) {
            // On selecting a spinner item
            s_bloodg = parent.getItemAtPosition(position).toString();

            // Showing selected spinner item
            Toast.makeText(parent.getContext(), "Selected: " + s_bloodg, Toast.LENGTH_LONG).show();
        }

        if (spin2.getId() == R.id.s_spinner2) {
            // On selecting a spinner item
            s_state = parent.getItemAtPosition(position).toString();

            // Showing selected spinner item
            Toast.makeText(parent.getContext(), "Selected: " + s_state, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
