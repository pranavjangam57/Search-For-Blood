package samples.exoguru.avinash;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class SqlDbHelper extends SQLiteOpenHelper {
	public static final String DATABASE_TABLE = "Blood";

	public static final String COLUMN1 = "bloodg";
	public static final String COLUMN2 = "fullname";
	public static final String COLUMN3 = "state";
	public static final String COLUMN4 = "city";
	public static final String COLUMN5 = "area";
	public static final String COLUMN6 = "contact";
	public static final String COLUMN7 = "email";
	public static final String COLUMN8 = "fav";

	private static final String SCRIPT_CREATE_DATABASE = "create table "
			+ DATABASE_TABLE + " (" + COLUMN1 + " text not null, " + COLUMN2
			+ " text not null, " + COLUMN3 + " text not null," + COLUMN4 + " text not null," + COLUMN5 + " text not null," + COLUMN6 + " text not null," + COLUMN7 + " text not null," + COLUMN8 + " text );";







	public SqlDbHelper(Context context, String name, CursorFactory factory, int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub

	}
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL(SCRIPT_CREATE_DATABASE);

	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);

		onCreate(db);
	}

}
