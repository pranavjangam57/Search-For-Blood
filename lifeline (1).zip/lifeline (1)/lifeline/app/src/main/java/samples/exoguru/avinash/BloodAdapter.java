package samples.exoguru.avinash;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Avinash on 1/14/2016.
 */
public class BloodAdapter extends BaseAdapter {

    Context context;
    ArrayList<Blood> bloodlist;

    public BloodAdapter(Context context, ArrayList<Blood> list) {

        this.context = context;
        bloodlist = list;
    }


    @Override
    public int getCount() {
        return bloodlist.size();
    }

    @Override
    public Object getItem(int position) {
        return bloodlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position,View convertView, ViewGroup arg2) {

       Blood blood=bloodlist.get(position);
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.row, null);

        }
        TextView tbdg = (TextView) convertView.findViewById(R.id.tbdg);
        tbdg.setText(blood.getBloodg());

        TextView tfullname = (TextView) convertView.findViewById(R.id.tname);
        tfullname.setText(blood.getFullname());

        TextView tstate = (TextView) convertView.findViewById(R.id.tstate);
        tstate.setText(blood.getState());

        TextView tcity = (TextView) convertView.findViewById(R.id.tcity);
        tcity.setText(blood.getCity());

        TextView tarea = (TextView) convertView.findViewById(R.id.tarea);
        tarea.setText(blood.getArea());

        TextView tcontact = (TextView) convertView.findViewById(R.id.tcontact);
        tcontact.setText(blood.getContact());

        TextView temail = (TextView) convertView.findViewById(R.id.temail);
        temail.setText(blood.getEmail());


        return convertView;
    }
}
