package samples.exoguru.avinash;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.media.SoundPool;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBarActivity;
;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Add extends ActionBarActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    Toolbar toolbar;
    EditText  add_fullname, add_city, add_area, add_contact, add_email;
    ImageButton add;
    SqlHandler sqlHandler;
    String add_bloodg,add_state;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);
        toolbar.setLogo(R.mipmap.logo1);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        add_fullname = (EditText) findViewById(R.id.add_fullname);

        add_city = (EditText) findViewById(R.id.add_city);
        add_area = (EditText) findViewById(R.id.add_area);
        add_contact = (EditText) findViewById(R.id.add_contact);
        add_email = (EditText) findViewById(R.id.add_email);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        Spinner spinner2 = (Spinner) findViewById(R.id.spinner2);

// Spinner click listener
        spinner.setOnItemSelectedListener(this);
        spinner2.setOnItemSelectedListener(this);
        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("A+");
        categories.add("B+");
        categories.add("AB+");
        categories.add("O+");
        categories.add("A-");
        categories.add("B-");
        categories.add("AB-");
        categories.add("O-");

        // Spinner Drop down elements

        List<String> categories1 = new ArrayList<String>();
        categories1.add("ANDRA PRADESH");
        categories1.add("ARUNACHAL PRADESH");
        categories1.add("ASSAM");
        categories1.add("BIHAR");
        categories1.add("CHHATTISGARH");
        categories1.add("GOA");
        categories1.add("GUJRAT");
        categories1.add("HARYANA");
        categories1.add("HIMACHAL PRADESH");
        categories1.add("JAMMU AND KASHMIR");
        categories1.add("JHARKHAND");
        categories1.add("KARNATAKA");
        categories1.add("KERALA");
        categories1.add("MADYA PRADESH");
        categories1.add("MAHARASHTRA");
        categories1.add("MANIPUR");
        categories1.add("MEGHALAYA");
        categories1.add("MIZORAM");
        categories1.add("NAGALAND");
        categories1.add("ORISSA");
        categories1.add("PUNJAB");
        categories1.add("RAJASTHAN");
        categories1.add("SIKKIM");
        categories1.add("TAMIL NADU");
        categories1.add("TRIPURA");
        categories1.add("UTTARANCHAL");
        categories1.add("UTTAR PRADESH");
        categories1.add("WEST BENGAL");
        categories1.add("CHANDIGARH");
        categories1.add("DAMAN AND DIU");
        categories1.add("DELHI");
        categories1.add("LAKSHDEEP");
        categories1.add("KAVARATTI");
        categories1.add("PONDICHERRY");








        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories1);


        //Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);



// attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
        spinner2.setAdapter(dataAdapter1);

        add = (ImageButton) findViewById(R.id.add);
        add.setOnClickListener(this);
        sqlHandler = new SqlHandler(this);














    }

    @Override
    public void onClick(View view) {
        String sadd_bloodg = String.valueOf(add_bloodg);
        sadd_bloodg = sadd_bloodg.toUpperCase();

        String sadd_fullname = String.valueOf(add_fullname.getText());
        sadd_fullname = sadd_fullname.toUpperCase();


        String sadd_state = String.valueOf(add_state);
        sadd_state = sadd_state.toUpperCase();

        String sadd_city = String.valueOf(add_city.getText());
        sadd_city = sadd_city.toUpperCase();


        String sadd_area = String.valueOf(add_area.getText());
        sadd_area = sadd_area.toUpperCase();

        String sadd_contact = String.valueOf(add_contact.getText());
        sadd_contact = sadd_contact.toUpperCase();

        String sadd_email = String.valueOf(add_email.getText());
        String q2 = "SELECT  contact FROM blood  where contact='" + sadd_contact + "'";
        Cursor c3 = sqlHandler.selectQuery(q2);

        if (view == add) {
            if (add_bloodg.trim().length() == 0 ||
                    add_fullname.getText().toString().trim().length() == 0 ||
                    add_state.trim().length() == 0 ||
                    add_city.getText().toString().trim().length() == 0 ||
                    add_area.getText().toString().trim().length() == 0 ||
                    add_email.getText().toString().trim().length() == 0 ||
                    add_contact.getText().toString().trim().length() == 0) {
                showMessage("Error", "Please enter all values");
                return;
            }

            if (c3 != null && c3.getCount() != 0) {


                showMessage("Error", "CONTACT NO ALREADY TAKEN");
                return;

            }

            String query = ("INSERT INTO blood(bloodg,fullname,state,city,area,contact,email) VALUES('" + sadd_bloodg + "','" + sadd_fullname +
                    "','" + sadd_state + "','" + sadd_city + "','" + sadd_area + "','" + sadd_contact + "','" + sadd_email + "');");
            sqlHandler.executeQuery(query);
            showMessage("Success", "Record added");
            clearText();
        }


    }


    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {

        add_fullname.setText("");

        add_area.setText("");
        add_city.setText("");
        add_contact.setText("");
        add_email.setText("");
        add_fullname.requestFocus();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);

        }
        if (id == R.id.life) {
            startActivity(new Intent(this, Utility.class));
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Spinner spin = (Spinner)parent;
        Spinner spin2 = (Spinner)parent;

        if(spin.getId() == R.id.spinner) {
            // On selecting a spinner item
            add_bloodg = parent.getItemAtPosition(position).toString();

            // Showing selected spinner item
            Toast.makeText(parent.getContext(), "Selected: " + add_bloodg, Toast.LENGTH_LONG).show();
        }



        if(spin2.getId() == R.id.spinner2) {
            // On selecting a spinner item
            add_state = parent.getItemAtPosition(position).toString();

            // Showing selected spinner item
            Toast.makeText(parent.getContext(), "Selected: " + add_state, Toast.LENGTH_LONG).show();

        }










    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
