package samples.exoguru.avinash;

import android.Manifest;
import android.app.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.PorterDuff;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.media.Image;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class Next extends FragmentActivity implements View.OnClickListener {
    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    TextView next_bloodg, next_state, next_city, next_area, next_email, next_name;
    ImageView phonecall, sms, email,fav;
    String ncontact, nemail,nbloodg,q2 ;
    SqlHandler sqlHandler;
    Cursor c3;
    TextView textview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        sqlHandler = new SqlHandler(this);
        textview=(TextView)findViewById(R.id.textnetwork);
        next_bloodg = (TextView) findViewById(R.id.next_tbdg);
        next_name = (TextView) findViewById(R.id.next_tname);
        next_state = (TextView) findViewById(R.id.next_tstate);
        next_city = (TextView) findViewById(R.id.next_tcity);
        next_area = (TextView) findViewById(R.id.next_tarea);
        next_email = (TextView) findViewById(R.id.next_temail);
        phonecall = (ImageView) findViewById(R.id.next_phone);


        fav= (ImageView) findViewById(R.id.fav);
        sms = (ImageView) findViewById(R.id.next_sms);
        email = (ImageView) findViewById(R.id.next_email);



        fav.setOnClickListener(this);
        phonecall.setOnClickListener(this);
        sms.setOnClickListener(this);
        email.setOnClickListener(this);



        //getting values from search activity when list clicked
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            nbloodg = extras.getString("bloodg");
            next_bloodg.setText(nbloodg);

            String nname = extras.getString("name");
            next_name.setText(nname);

            String nstate = extras.getString("state");
            next_state.setText(nstate);

            String ncity = extras.getString("city");
            next_city.setText(ncity);

            String narea = extras.getString("area");
            next_area.setText(narea);

            nemail = extras.getString("email");
            next_email.setText(nemail);

            ncontact = extras.getString("contact");
        }


        editor.putString("shared_contact", nbloodg);  // Saving string

        // Save the changes in SharedPreferences
        editor.commit(); // commit changes
        q2 = "SELECT  contact FROM blood  where contact='" + ncontact + "' and fav='true'";
         c3 = sqlHandler.selectQuery(q2);
        if (c3 != null && c3.getCount() != 0) {
            Resources res = this.getResources();
            final ImageView image = (ImageView) findViewById(R.id.fav);
            final int newColor = res.getColor(R.color.new_color);
            image.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

        }

//for checking internet connection
        ConnectivityManager connectivityManager= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();

        if(networkInfo!=null && networkInfo.isConnected()) {

            textview.setVisibility(View.INVISIBLE);

            setUpMapIfNeeded();

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                mMap.setMyLocationEnabled(true);
            } else {
                // Show rationale and request permission.
            }


        }
        else {

        }









    }





    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }


    private void setUpMap() {
        String location=next_city.getText().toString();

        Geocoder geocoder = new Geocoder(this);
        List<Address> list = null;
        try {
            list = geocoder.getFromLocationName(location, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Address add = list.get(0);
        String locality = add.getLocality();
        LatLng ll = new LatLng(add.getLatitude(), add.getLongitude());
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(ll,13);
        mMap.moveCamera(update);




        mMap.addMarker(new MarkerOptions().position(new LatLng(add.getLatitude(), add.getLongitude())).title("Blood").alpha(0.7f).icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_launcher1)));

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_next, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }




    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    @Override
    public void onClick(View v) {
        if (v == phonecall) {


            Intent call = new Intent(Intent.ACTION_DIAL);
            call.setData(Uri.parse("tel:" + ncontact));
            startActivity(call);


        }


        if (v == sms) {
            String message = "Life line Donate blood";

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:" + ncontact));
            intent.putExtra("sms_body", message);
            startActivity(intent);

        }
            if (v == email) {
                String subject = "This is subject of life line";
                String body = "This is body of life line";


                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto", nemail, null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
                emailIntent.putExtra(Intent.EXTRA_TEXT, body);
                startActivity(Intent.createChooser(emailIntent, "Send email..."));




            }



        if (v == fav) {
            if (c3 != null && c3.getCount() != 0) {


                showMessage("Error", "ALREADY FAVOURITE ");
             return;
            }

            String query = ("UPDATE blood SET fav='true' WHERE contact='" + ncontact + "' ");
            sqlHandler.executeQuery(query);
            Resources res = this.getResources();
            final ImageView image = (ImageView) findViewById(R.id.fav);
            final int newColor = res.getColor(R.color.new_color);
            image.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);


            Toast.makeText(Next.this, "Success:FAVOURITE ADDED", Toast.LENGTH_SHORT).show();


        }
        }


    }



